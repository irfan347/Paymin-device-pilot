package pk.paymint.lock;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.Intent;
import android.os.Bundle;

/**
 * Handles the Android 10+ (API 29+) Device Owner provisioning handshake used by QR enrollment.
 * Without these two steps, modern Android aborts with "Can't set up device".
 *
 *  - GET_PROVISIONING_MODE  -> tell the system we want a FULLY MANAGED (device owner) device.
 *  - ADMIN_POLICY_COMPLIANCE -> apply our owner policies, then report success so setup can finish.
 */
public class ProvisioningActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String action = getIntent() != null ? getIntent().getAction() : null;

        if ("android.app.action.GET_PROVISIONING_MODE".equals(action)) {
            Intent result = new Intent();
            result.putExtra(DevicePolicyManager.EXTRA_PROVISIONING_MODE,
                    DevicePolicyManager.PROVISIONING_MODE_FULLY_MANAGED_DEVICE);
            setResult(RESULT_OK, result);
        } else if ("android.app.action.ADMIN_POLICY_COMPLIANCE".equals(action)) {
            try { Locker.applyOwnerPolicies(this); } catch (Exception ignored) {}
            setResult(RESULT_OK);
        } else {
            setResult(RESULT_OK);
        }
        finish();
    }
}
