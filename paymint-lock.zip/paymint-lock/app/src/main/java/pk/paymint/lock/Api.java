package pk.paymint.lock;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/** Tiny HTTP helper that talks to the Paymint backend. No third-party libraries. */
public class Api {
    public static final String PREFS = "paymint";
    public static final String KEY_BASE = "base_url";
    public static final String KEY_DEVICE = "device_id";
    // stored so the lock can be enforced OFFLINE (no internet can't dodge it)
    public static final String KEY_NEXT_LOCK = "next_lock_date"; // YYYY-MM-DD or ""
    public static final String KEY_GRACE = "grace_days";
    public static final String KEY_LAST_SYNC = "last_sync";       // epoch millis of last successful poll
    public static final String KEY_SRV_LOCKED = "srv_locked";     // last server decision
    public static final String KEY_REGISTERED = "registered";     // device is linked to a customer

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** A stable device id generated once and kept locally. */
    public static String deviceId(Context c) {
        SharedPreferences p = prefs(c);
        String id = p.getString(KEY_DEVICE, null);
        if (id == null) {
            id = "PM-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
            p.edit().putString(KEY_DEVICE, id).apply();
        }
        return id;
    }

    public static String baseUrl(Context c) {
        return prefs(c).getString(KEY_BASE, BuildConfig.DEFAULT_BASE_URL).replaceAll("/+$", "");
    }

    public static void setBaseUrl(Context c, String url) {
        prefs(c).edit().putString(KEY_BASE, url).apply();
    }

    /** Result of a status poll. */
    public static class Status {
        public boolean ok;        // request succeeded
        public boolean locked;    // backend says device should be locked
        public boolean registered;// device is linked to a customer
        public String message = "";
    }

    /** Reads the phone IMEI. Works when the app is Device Owner (granted READ_PHONE_STATE). "" if unavailable. */
    public static String imei(Context c) {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "";
            String id;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) id = tm.getImei();
            else id = tm.getDeviceId();
            return id == null ? "" : id;
        } catch (Throwable t) { return ""; }
    }

    /** GET /api/device/status?device_id=...&imei=... */
    public static Status checkStatus(Context c) {
        Status s = new Status();
        HttpURLConnection conn = null;
        try {
            String url = baseUrl(c) + "/api/device/status?device_id="
                    + URLEncoder.encode(deviceId(c), "UTF-8");
            String im = imei(c);
            if (im.length() >= 10) url += "&imei=" + URLEncoder.encode(im, "UTF-8");
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            String body = read(conn, code >= 400);
            JSONObject j = new JSONObject(body);
            if (code == 200) {
                s.ok = true;
                s.registered = true;
                s.locked = j.optBoolean("locked", false);
                s.message = j.optString("message", "");
                // remember the schedule so we can enforce the lock even with no internet
                SharedPreferences.Editor e = prefs(c).edit();
                e.putString(KEY_NEXT_LOCK, j.optString("next_lock_date", ""));
                e.putInt(KEY_GRACE, j.optInt("grace_days", 2));
                e.putBoolean(KEY_SRV_LOCKED, s.locked);
                e.putBoolean(KEY_REGISTERED, true);
                e.putLong(KEY_LAST_SYNC, System.currentTimeMillis());
                e.apply();
            } else if (code == 404) {
                // device not registered yet — do not lock
                s.ok = true;
                s.registered = false;
                s.locked = false;
                prefs(c).edit().putBoolean(KEY_REGISTERED, false).apply();
            } else {
                s.ok = false;
            }
        } catch (Exception e) {
            s.ok = false; // network error
        } finally {
            if (conn != null) conn.disconnect();
        }
        return s;
    }

    /** True once the device has been linked to a customer in the panel. */
    public static boolean isRegistered(Context c) {
        return prefs(c).getBoolean(KEY_REGISTERED, false);
    }

    private static String todayStr() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /**
     * Offline-capable lock decision. Returns true if the device should be locked based on what we
     * last learned from the server, even if there is no internet right now:
     *  - the server last said locked, OR
     *  - the next due date has arrived and we haven't been told it's paid, OR
     *  - we haven't managed to sync for longer than the grace period.
     * Returns false until the device has synced at least once (not yet set up).
     */
    public static boolean shouldLockOffline(Context c) {
        SharedPreferences p = prefs(c);
        long lastSync = p.getLong(KEY_LAST_SYNC, 0);
        if (lastSync == 0) return false; // never synced yet
        if (p.getBoolean(KEY_SRV_LOCKED, false)) return true;
        int grace = p.getInt(KEY_GRACE, 2);
        long ageDays = (System.currentTimeMillis() - lastSync) / 86400000L;
        if (ageDays > grace) return true; // offline too long
        String next = p.getString(KEY_NEXT_LOCK, "");
        if (next != null && next.length() == 10 && todayStr().compareTo(next) >= 0) return true;
        return false;
    }

    private static String read(HttpURLConnection conn, boolean err) throws Exception {
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                err ? conn.getErrorStream() : conn.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
