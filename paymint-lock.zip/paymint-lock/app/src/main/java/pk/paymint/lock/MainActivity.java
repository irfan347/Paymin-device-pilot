package pk.paymint.lock;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Customer home: shows the installments / payment screen (the server's /me page) inside the app,
 * so the customer has ONE app for everything. A small "Setup" button opens the device-owner
 * setup/consent screen used by the shopkeeper at provisioning. The lock service runs in the
 * background regardless.
 */
public class MainActivity extends Activity {

    private WebView web;
    private String loadedBase = "";
    private Button setupBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0B1220"));

        // top bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(12), dp(12), dp(12));
        bar.setBackgroundColor(Color.parseColor("#0E1A2B"));

        // logo mark
        android.widget.ImageView logo = new android.widget.ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(30), dp(30));
        llp.setMarginEnd(dp(9));
        bar.addView(logo, llp);

        // bold two-tone title: Pay (white) + mint (green)
        TextView title = new TextView(this);
        title.setText(android.text.Html.fromHtml("Pay<font color='#12D6A0'>mint</font>"));
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(-0.02f);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bar.addView(title, tlp);

        setupBtn = new Button(this);
        setupBtn.setText("Setup");
        setupBtn.setAllCaps(true);
        setupBtn.setTextSize(13);
        setupBtn.setTextColor(Color.parseColor("#12D6A0"));
        setupBtn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        setupBtn.setBackground(getResources().getDrawable(R.drawable.btn_pill));
        setupBtn.setPadding(dp(20), dp(9), dp(20), dp(9));
        setupBtn.setStateListAnimator(null);
        setupBtn.setMinWidth(0); setupBtn.setMinHeight(0);
        setupBtn.setOnClickListener(v -> startActivity(new Intent(this, SetupActivity.class)));
        bar.addView(setupBtn);

        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // webview
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);           // /me uses localStorage for token + language
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onReceivedError(WebView v, int code, String desc, String url) {
                v.loadData("<html><body style='background:#0B1220;color:#93A4BF;font-family:sans-serif;padding:24px;text-align:center'>"
                        + "<h3 style='color:#12D6A0'>Paymint</h3><p>Internet nahi mil raha. Please check your connection and reopen the app.</p></body></html>",
                        "text/html", "utf-8");
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        loadedBase = Api.baseUrl(this);
        web.loadUrl(loadedBase + "/me");

        // keep the lock monitor running if protection is set up
        if (Locker.isDeviceOwner(this)) Locker.applyOwnerPolicies(this);
        if (Locker.isAdminActive(this) || Locker.isDeviceOwner(this)) {
            PollService.start(this);
            AlarmReceiver.schedule(this);
        }
        refreshSetupButton();
    }

    /**
     * Once setup is done (protection enabled AND the device is linked to a customer in the panel),
     * hide the Setup button so the customer only sees their login/installments. Shows a one-time
     * "connected successfully" notice when the device first links.
     */
    private void refreshSetupButton() {
        // quick local decision first
        boolean protectedNow = Locker.isAdminActive(this) || Locker.isDeviceOwner(this);
        if (setupBtn != null) setupBtn.setVisibility(protectedNow && Api.isRegistered(this) ? View.GONE : View.VISIBLE);
        // then confirm with the server in the background
        new Thread(() -> {
            boolean wasRegistered = Api.isRegistered(this);
            Api.checkStatus(this); // updates the stored "registered" flag
            boolean nowRegistered = Api.isRegistered(this);
            boolean prot = Locker.isAdminActive(this) || Locker.isDeviceOwner(this);
            runOnUiThread(() -> {
                if (setupBtn != null) setupBtn.setVisibility(prot && nowRegistered ? View.GONE : View.VISIBLE);
                if (!wasRegistered && nowRegistered) {
                    android.widget.Toast.makeText(this, "Device connected successfully ✓", android.widget.Toast.LENGTH_LONG).show();
                    notifyConnected();
                }
            });
        }).start();
    }

    private void notifyConnected() {
        android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        String ch = "paymint_setup";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new android.app.NotificationChannel(ch, "Paymint", android.app.NotificationManager.IMPORTANCE_DEFAULT));
        }
        android.app.Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new android.app.Notification.Builder(this, ch) : new android.app.Notification.Builder(this);
        android.app.Notification n = b.setContentTitle("Paymint")
                .setContentText("Device connected successfully. Setup complete.")
                .setSmallIcon(R.drawable.ic_stat).setAutoCancel(true).build();
        try { nm.notify(11, n); } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web == null) return;
        // If the server address changed (e.g. just saved in Setup), load the new one; else refresh.
        String cur = Api.baseUrl(this);
        if (!cur.equals(loadedBase)) {
            loadedBase = cur;
            web.loadUrl(cur + "/me");
        } else {
            web.reload();
        }
        refreshSetupButton();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
