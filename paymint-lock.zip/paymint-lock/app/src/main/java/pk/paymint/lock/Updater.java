package pk.paymint.lock;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.app.PendingIntent;
import android.os.Build;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Over-the-air self-update. Asks the server for the latest version; if it is newer than this build,
 * downloads the APK and installs it. As Device Owner the install is silent (no user action).
 * Updates only work because every build is signed with the same key (see build.gradle).
 */
public class Updater {

    private static long lastCheck = 0;

    /** Check at most once per ~6 hours, in the background. Safe to call often. */
    public static void maybeCheck(Context c) {
        long now = System.currentTimeMillis();
        if (now - lastCheck < 6 * 60 * 60 * 1000L) return;
        lastCheck = now;
        new Thread(() -> run(c)).start();
    }

    private static void run(Context c) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(Api.baseUrl(c) + "/api/app/latest");
            conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            int code = conn.getResponseCode();
            if (code != 200) return;
            StringBuilder sb = new StringBuilder();
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line; while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            JSONObject j = new JSONObject(sb.toString());
            int latest = j.optInt("version_code", 0);
            String apkUrl = j.optString("apk_url", "");
            if (latest <= BuildConfig.VERSION_CODE || apkUrl.isEmpty()) return;
            downloadAndInstall(c, apkUrl);
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static void downloadAndInstall(Context c, String apkUrl) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(apkUrl).openConnection();
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(60000);
            conn.setInstanceFollowRedirects(true);
            if (conn.getResponseCode() != 200) return;

            PackageInstaller pi = c.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = pi.createSession(params);
            PackageInstaller.Session session = pi.openSession(sessionId);

            try (InputStream in = conn.getInputStream();
                 OutputStream out = session.openWrite("paymint_update", 0, -1)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                session.fsync(out);
            }

            Intent intent = new Intent(c, MainActivity.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT
                    | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent pending = PendingIntent.getActivity(c, 0, intent, flags);
            session.commit(pending.getIntentSender());
            session.close();
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
