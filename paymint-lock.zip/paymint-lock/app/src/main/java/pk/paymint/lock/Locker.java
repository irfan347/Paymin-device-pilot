package pk.paymint.lock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.UserManager;

/** Applies / clears the lock based on backend status. */
public class Locker {

    public static boolean isDeviceOwner(Context c) {
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        return dpm != null && dpm.isDeviceOwnerApp(c.getPackageName());
    }

    /**
     * When the app is Device Owner, lock the phone down to EMI-financing level:
     * block factory reset, safe boot and uninstalling the app, and allow this app
     * to pin the lock screen. Applied with the customer's consent.
     */
    public static void applyOwnerPolicies(Context c) {
        if (!isDeviceOwner(c)) return;
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = PaymintAdminReceiver.getComponent(c);
        String[] owner = {
                UserManager.DISALLOW_FACTORY_RESET,        // no factory reset from Settings
                UserManager.DISALLOW_SAFE_BOOT,            // no safe-mode boot
                UserManager.DISALLOW_ADD_USER,             // no new users/guest
                UserManager.DISALLOW_DEBUGGING_FEATURES,   // no USB debugging / ADB
                UserManager.DISALLOW_APPS_CONTROL,         // can't force-stop or clear data of our app
                UserManager.DISALLOW_UNINSTALL_APPS,       // can't uninstall apps
                UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES, // no sideloading other apps
                UserManager.DISALLOW_CONFIG_VPN,           // can't route around with a VPN
                UserManager.DISALLOW_CONFIG_TETHERING,
                UserManager.DISALLOW_USB_FILE_TRANSFER,
                UserManager.DISALLOW_CONFIG_DATE_TIME,     // can't change the clock
                UserManager.DISALLOW_MOUNT_PHYSICAL_MEDIA
        };
        for (String k : owner) {
            try { dpm.addUserRestriction(admin, k); } catch (Exception ignored) {}
        }
        try { dpm.setUninstallBlocked(admin, c.getPackageName(), true); } catch (Exception ignored) {}
        try { dpm.setLockTaskPackages(admin, new String[]{ c.getPackageName() }); } catch (Exception ignored) {}
    }

    public static boolean isAdminActive(Context c) {
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        return dpm != null && dpm.isAdminActive(PaymintAdminReceiver.getComponent(c));
    }

    /**
     * While locked (Device Owner only): block outgoing calls and SMS so the phone can't be used,
     * while emergency calls stay allowed. Combined with the pinned lock screen (kiosk), the
     * customer can't open any app, dialer or browser — so mobile data is effectively unusable too.
     * Cleared automatically when unlocked.
     */
    public static void setLockedRestrictions(Context c, boolean on) {
        if (!isDeviceOwner(c)) return;
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = PaymintAdminReceiver.getComponent(c);
        // Note: we do NOT block adding Wi-Fi here — a locked phone must still be able to
        // get online to reach the server and unlock once payment is confirmed.
        String[] keys = {
                UserManager.DISALLOW_OUTGOING_CALLS,
                UserManager.DISALLOW_SMS,
                UserManager.DISALLOW_DATA_ROAMING
        };
        for (String k : keys) {
            try {
                if (on) dpm.addUserRestriction(admin, k);
                else dpm.clearUserRestriction(admin, k);
            } catch (Exception ignored) {}
        }
    }

    private static final String LOCK_CH = "paymint_lock";
    private static final int LOCK_NOTIF = 7;

    /** Called by the poller. locked=true -> show the lock screen; false -> dismiss it. */
    public static void apply(Context c, boolean locked) {
        setLockedRestrictions(c, locked);
        if (locked) {
            // Primary, background-safe trigger: a full-screen-intent notification (same mechanism
            // incoming-call apps use) so the lock screen appears even from the background service.
            showLockNotification(c);
            // Direct launch too (works immediately when the app/service is foreground or Device Owner).
            Intent i = new Intent(c, LockActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            try { c.startActivity(i); } catch (Exception ignored) {}
            // In Device Admin–only mode (no Device Owner pinning), fall back to the system keyguard.
            if (!isDeviceOwner(c)) {
                try {
                    DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
                    if (dpm != null && isAdminActive(c)) dpm.lockNow();
                } catch (SecurityException ignored) {}
            }
        } else {
            cancelLockNotification(c);
            LockActivity.dismiss();
        }
    }

    private static void showLockNotification(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(LOCK_CH, "Payment lock", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Shows the lock screen when a payment is overdue.");
            nm.createNotificationChannel(ch);
        }
        Intent full = new Intent(c, LockActivity.class);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(c, 0, full, flags);
        Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(c, LOCK_CH)
                : new Notification.Builder(c);
        b.setContentTitle("Paymint — device locked")
                .setContentText("An installment is overdue. Tap to pay and unlock.")
                .setSmallIcon(R.drawable.ic_stat)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_CALL)
                .setFullScreenIntent(pi, true);
        try { nm.notify(LOCK_NOTIF, b.build()); } catch (Exception ignored) {}
    }

    private static void cancelLockNotification(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(LOCK_NOTIF);
    }
}
