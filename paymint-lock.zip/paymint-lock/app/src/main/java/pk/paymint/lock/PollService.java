package pk.paymint.lock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/** Foreground service that polls the backend for lock status. */
public class PollService extends Service {
    private static final String CH = "paymint_monitor";
    private static final long INTERVAL_MS = 60_000; // poll every 60s
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;

    public static void start(Context c) {
        Intent i = new Intent(c, PollService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i);
        else c.startService(i);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, buildNotification());
        AlarmReceiver.schedule(this); // safety net in case we get killed
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) {
            running = true;
            handler.post(poll);
        }
        return START_STICKY;
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            new Thread(() -> {
                final Api.Status s = Api.checkStatus(PollService.this);
                // Decide using the latest server answer when online, and the stored schedule when
                // offline — so turning off internet cannot dodge the lock.
                final boolean lock = (s.ok && s.registered && s.locked) || Api.shouldLockOffline(PollService.this);
                handler.post(() -> Locker.apply(PollService.this, lock));
            }).start();
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH, "Paymint", NotificationManager.IMPORTANCE_MIN);
            ch.setDescription("Keeps your Paymint installment status up to date.");
            if (nm != null) nm.createNotificationChannel(ch);
        }
        Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(this, CH)
                : new Notification.Builder(this);
        return b.setContentTitle("Paymint")
                .setContentText("Installment status active")
                .setSmallIcon(R.drawable.ic_stat)
                .setOngoing(true)
                .build();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
