package pk.paymint.lock;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;

/** Full-screen lock notice shown when an installment is overdue. Allows emergency calls. */
public class LockActivity extends Activity {

    private static WeakReference<LockActivity> INSTANCE;
    private TextView msgView;

    /** Called by the poller when the backend reports the device is no longer locked. */
    public static void dismiss() {
        if (INSTANCE != null) {
            LockActivity a = INSTANCE.get();
            if (a != null) a.runOnUiThread(a::unlockAndFinish);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        INSTANCE = new WeakReference<>(this);

        // Show over the keyguard and keep the screen on.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        // If we're device owner, pin the screen and block the status bar / shortcuts.
        if (Locker.isDeviceOwner(this)) {
            try { startLockTask(); } catch (Exception ignored) {}
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                ComponentName admin = PaymintAdminReceiver.getComponent(this);
                dpm.setStatusBarDisabled(admin, true);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) dpm.setLockTaskFeatures(admin, 0); // nothing
            } catch (Exception ignored) {}
        }

        setContentView(buildUi());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#0A2540"));
        int pad = dp(28);
        root.setPadding(pad, pad, pad, pad);

        TextView brand = new TextView(this);
        brand.setText("Paymint");
        brand.setTextColor(Color.parseColor("#12D6A0"));
        brand.setTextSize(28);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand);

        TextView lock = new TextView(this);
        lock.setText("🔒  Device locked");
        lock.setTextColor(Color.WHITE);
        lock.setTextSize(22);
        lock.setGravity(Gravity.CENTER);
        lock.setPadding(0, dp(18), 0, dp(10));
        root.addView(lock);

        msgView = new TextView(this);
        msgView.setText("An installment payment is overdue, so this device is locked — calls and apps are paused until payment. Emergency calls still work. Pay your due installment and the device unlocks automatically once your payment is confirmed.");
        msgView.setTextColor(Color.parseColor("#C7D4E6"));
        msgView.setTextSize(16);
        msgView.setGravity(Gravity.CENTER);
        msgView.setPadding(0, 0, 0, dp(28));
        root.addView(msgView);

        Button refresh = new Button(this);
        refresh.setText("I've paid — check again");
        refresh.setOnClickListener(v -> recheck());
        root.addView(refresh, lp());

        Button emergency = new Button(this);
        emergency.setText("Emergency call");
        emergency.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:")));
            } catch (Exception ignored) {}
        });
        root.addView(emergency, lp());

        return root;
    }

    private void recheck() {
        Toast.makeText(this, "Checking…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            Api.Status s = Api.checkStatus(this);
            runOnUiThread(() -> {
                if (s.ok && !s.locked) unlockAndFinish();
                else if (s.ok) Toast.makeText(this, "Still unpaid. Please complete your payment.", Toast.LENGTH_LONG).show();
                else Toast.makeText(this, "No internet. Try again.", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private void unlockAndFinish() {
        if (Locker.isDeviceOwner(this)) {
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                dpm.setStatusBarDisabled(PaymintAdminReceiver.getComponent(this), false);
            } catch (Exception ignored) {}
            try { stopLockTask(); } catch (Exception ignored) {}
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        // Block back — the device stays locked until payment.
    }

    @Override
    protected void onDestroy() {
        if (INSTANCE != null && INSTANCE.get() == this) INSTANCE = null;
        super.onDestroy();
    }

    private LinearLayout.LayoutParams lp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                dp(260), LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(12);
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
