package pk.paymint.lock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Safety net: a repeating alarm that revives the polling service if the phone's battery saver
 * killed it in the background, then re-arms itself. Works in Doze via setAndAllowWhileIdle.
 */
public class AlarmReceiver extends BroadcastReceiver {
    private static final int REQ = 42;
    private static final long INTERVAL = 15 * 60 * 1000L; // ~15 min

    public static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, AlarmReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQ, i, flags);
        long when = System.currentTimeMillis() + INTERVAL;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // Enforce the lock right away (works offline) and make sure the service is running.
        try { Locker.apply(context, Api.shouldLockOffline(context)); } catch (Exception ignored) {}
        PollService.start(context);
        schedule(context); // re-arm for the next interval
    }
}
