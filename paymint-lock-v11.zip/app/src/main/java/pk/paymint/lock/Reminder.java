package pk.paymint.lock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Shows the customer a friendly reminder a few days BEFORE the device would lock, so they can pay
 * on time and avoid the lock. Fires at most once per day. Uses the schedule the server already sends
 * (next_lock_date + remind_days), so it works offline too.
 */
public class Reminder {
    private static final String CH = "paymint_reminder";
    private static final String KEY_LAST_NOTIFIED = "remind_last_date";

    public static void maybeNotify(Context c) {
        try {
            SharedPreferences p = Api.prefs(c);
            String next = p.getString(Api.KEY_NEXT_LOCK, "");
            if (next == null || next.length() != 10) return;        // no due date known
            int remindDays = p.getInt(Api.KEY_REMIND_DAYS, 3);
            if (remindDays <= 0) return;

            long now = System.currentTimeMillis();
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            long lockTime = fmt.parse(next).getTime();
            long daysLeft = (long) Math.ceil((lockTime - startOfDay(now)) / 86400000.0);

            // Only remind within the window, and not once it's already the lock day or past.
            if (daysLeft <= 0 || daysLeft > remindDays) return;

            String today = fmt.format(new Date(now));
            if (today.equals(p.getString(KEY_LAST_NOTIFIED, ""))) return; // already reminded today
            p.edit().putString(KEY_LAST_NOTIFIED, today).apply();

            String msg = (daysLeft == 1)
                    ? "Aapki installment kal due hai. Aaj hi ada karein taake phone lock na ho."
                    : ("Aapki installment " + daysLeft + " din mein due hai. Waqt par ada karein.");
            show(c, "Paymint — installment reminder", msg);
        } catch (Throwable ignored) {}
    }

    private static long startOfDay(long t) {
        return t - (t % 86400000L);
    }

    private static void show(Context c, String title, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH, "Payment reminders", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Reminds you before an installment is due.");
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(c, CH)
                : new Notification.Builder(c);
        nm.notify(42, b.setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(R.drawable.ic_stat)
                .setAutoCancel(true)
                .build());
    }
}
