package pk.paymint.lock;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/** Tiny HTTP helper that talks to the Paymint backend. No third-party libraries. */
public class Api {
    public static final String PREFS = "paymint";
    public static final String KEY_BASE = "base_url";
    public static final String KEY_DEVICE = "device_id";
    // stored so the lock can be enforced OFFLINE (no internet can't dodge it)
    public static final String KEY_NEXT_LOCK = "next_lock_date"; // YYYY-MM-DD or ""
    public static final String KEY_GRACE = "grace_days";
    public static final String KEY_LAST_SYNC = "last_sync";       // epoch millis of last successful poll
    public static final String KEY_SRV_LOCKED = "srv_locked";     // last server decision
    public static final String KEY_REGISTERED = "registered";     // device is linked to a customer
    public static final String KEY_EVER_REGISTERED = "ever_registered"; // has been linked at least once (setup done)
    public static final String KEY_FRP_ACCOUNTS = "frp_accounts"; // dealer Google account IDs that may pass FRP after a reset
    public static final String KEY_SMS_SECRET = "sms_secret";     // secret word for SMS remote lock/unlock
    public static final String KEY_REMIND_DAYS = "remind_days";   // days before lock to remind the customer
    public static final String KEY_SMS_FORCE = "sms_force";       // -1 none, 1 force-lock, 0 force-unlock (set via SMS)
    public static final String KEY_LOCK_ON_SIM = "lock_on_sim";   // 1 = lock the phone if the SIM is swapped
    public static final String KEY_SIM_BASE = "sim_base";         // the SIM serial seen at enrollment (baseline)

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** A stable device id generated once and kept locally. */
    public static String deviceId(Context c) {
        SharedPreferences p = prefs(c);
        String id = p.getString(KEY_DEVICE, null);
        if (id == null) {
            id = "PM-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
            p.edit().putString(KEY_DEVICE, id).apply();
        }
        return id;
    }

    public static String baseUrl(Context c) {
        return prefs(c).getString(KEY_BASE, BuildConfig.DEFAULT_BASE_URL).replaceAll("/+$", "");
    }

    public static void setBaseUrl(Context c, String url) {
        prefs(c).edit().putString(KEY_BASE, url).apply();
    }

    /** Result of a status poll. */
    public static class Status {
        public boolean ok;        // request succeeded
        public boolean locked;    // backend says device should be locked
        public boolean registered;// device is linked to a customer
        public String message = "";
    }

    /** Reads the phone IMEI. Works when the app is Device Owner (granted READ_PHONE_STATE). "" if unavailable. */
    public static String imei(Context c) {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "";
            String id;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) id = tm.getImei();
            else id = tm.getDeviceId();
            return id == null ? "" : id;
        } catch (Throwable t) { return ""; }
    }

    /** SIM ICCID (serial). As Device Owner we can read it; used to detect SIM swaps. */
    public static String simSerial(Context c) {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "";
            String s = tm.getSimSerialNumber();
            return s == null ? "" : s;
        } catch (Throwable t) { return ""; }
    }

    /** SIM phone number, if the carrier exposes it (often empty — best effort). */
    public static String simNumber(Context c) {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "";
            String n = tm.getLine1Number();
            return n == null ? "" : n;
        } catch (Throwable t) { return ""; }
    }

    /** Network/carrier name (e.g. Jazz, Zong). */
    public static String carrier(Context c) {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "";
            String n = tm.getNetworkOperatorName();
            if (n == null || n.isEmpty()) n = tm.getSimOperatorName();
            return n == null ? "" : n;
        } catch (Throwable t) { return ""; }
    }

    /** Best known location as "lat,lng" from any available provider, or "" if none/no permission. */
    public static String lastLocation(Context c) {
        try {
            android.location.LocationManager lm =
                    (android.location.LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return "";
            android.location.Location best = null;
            for (String prov : lm.getProviders(true)) {
                try {
                    android.location.Location l = lm.getLastKnownLocation(prov);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (SecurityException ignored) {}
            }
            if (best == null) return "";
            return String.format(Locale.US, "%.5f,%.5f", best.getLatitude(), best.getLongitude());
        } catch (Throwable t) { return ""; }
    }

    /** The SMS remote-lock secret word pushed by the server ("" = feature disabled). */
    public static String smsSecret(Context c) {
        return prefs(c).getString(KEY_SMS_SECRET, "");
    }

    /** True if there is physically NO SIM in the phone (reliable, not a read glitch). */
    public static boolean simAbsent(Context c) {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return false;
            return tm.getSimState() == android.telephony.TelephonyManager.SIM_STATE_ABSENT;
        } catch (Throwable t) { return false; }
    }

    /**
     * SIM-guard violation: the feature is on, we have a baseline SIM, and NOW either the SIM has been
     * removed or a different SIM is inserted. Used to lock the phone immediately (online or offline).
     */
    public static boolean simViolation(Context c) {
        SharedPreferences p = prefs(c);
        if (p.getInt(KEY_LOCK_ON_SIM, 0) != 1) return false;
        // Only matters when the phone is ALREADY in a locked/overdue state. A paying customer who
        // simply changes their SIM is NOT locked — this is purely an anti-escape guard for a
        // phone that is already locked because the installment date has passed.
        if (!overdueNow(p)) return false;
        String base = p.getString(KEY_SIM_BASE, "");
        if (base.isEmpty()) return false;            // no baseline yet -> nothing to compare
        if (simAbsent(c)) return true;               // SIM pulled out while locked
        String cur = simSerial(c);
        return !cur.isEmpty() && !cur.equals(base);  // a different SIM inserted while locked
    }

    /** True if the device is in a locked/overdue state: due date reached, or the server last said locked. */
    private static boolean overdueNow(SharedPreferences p) {
        if (p.getBoolean(KEY_SRV_LOCKED, false)) return true;
        String next = p.getString(KEY_NEXT_LOCK, "");
        return next != null && next.length() == 10 && todayStr().compareTo(next) >= 0;
    }

    /** GET /api/device/status?device_id=...&imei=... */
    public static Status checkStatus(Context c) {
        Status s = new Status();
        HttpURLConnection conn = null;
        try {
            String url = baseUrl(c) + "/api/device/status?device_id="
                    + URLEncoder.encode(deviceId(c), "UTF-8");
            String im = imei(c);
            if (im.length() >= 10) url += "&imei=" + URLEncoder.encode(im, "UTF-8");
            // Extra layers: report current SIM + carrier + last known location (best-effort).
            try {
                String sim = simSerial(c);   if (!sim.isEmpty())   url += "&sim="     + URLEncoder.encode(sim, "UTF-8");
                String num = simNumber(c);   if (!num.isEmpty())   url += "&simnum="  + URLEncoder.encode(num, "UTF-8");
                String car = carrier(c);     if (!car.isEmpty())   url += "&carrier=" + URLEncoder.encode(car, "UTF-8");
                String loc = lastLocation(c);
                if (!loc.isEmpty()) { String[] ll = loc.split(","); url += "&lat=" + ll[0] + "&lng=" + ll[1]; }
            } catch (Throwable ignored) {}
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            String body = read(conn, code >= 400);
            JSONObject j = new JSONObject(body);
            if (code == 200) {
                s.ok = true;
                s.registered = true;
                s.locked = j.optBoolean("locked", false);
                s.message = j.optString("message", "");
                // remember the schedule so we can enforce the lock even with no internet
                SharedPreferences.Editor e = prefs(c).edit();
                e.putString(KEY_NEXT_LOCK, j.optString("next_lock_date", ""));
                e.putInt(KEY_GRACE, j.optInt("grace_days", 2));
                e.putString(KEY_FRP_ACCOUNTS, j.optString("frp_accounts", "")); // dealer account IDs for reset protection
                e.putString(KEY_SMS_SECRET, j.optString("sms_secret", ""));      // SMS remote-lock secret
                e.putInt(KEY_REMIND_DAYS, j.optInt("remind_days", 3));            // reminder lead time
                e.putInt(KEY_LOCK_ON_SIM, j.optInt("lock_on_sim_change", 0));     // auto-lock on SIM swap
                // SIM baseline: set it at enrollment, and re-set it whenever the server says it is happy
                // with the current SIM (sim_ok=1) — e.g. after the dealer clears a SIM alert. Only when a
                // SIM is actually present, so a pulled-out SIM can't quietly reset the baseline.
                String curSim = simSerial(c);
                boolean simOk = j.optInt("sim_ok", 1) == 1;
                boolean noBaseline = prefs(c).getString(KEY_SIM_BASE, "").isEmpty();
                if (!curSim.isEmpty() && (noBaseline || simOk)) e.putString(KEY_SIM_BASE, curSim);
                e.putBoolean(KEY_SRV_LOCKED, s.locked);
                e.putBoolean(KEY_REGISTERED, true);
                e.putBoolean(KEY_EVER_REGISTERED, true); // setup is complete once linked at least once
                e.putLong(KEY_LAST_SYNC, System.currentTimeMillis());
                e.apply();
            } else if (code == 404) {
                // Device not registered (never linked yet, OR the server lost its record, e.g. DB reset).
                // Treat as "not linked": do NOT keep the phone bricked on a stale cached lock.
                // Clear the offline-lock cache so shouldLockOffline() won't re-lock from old data.
                s.ok = true;
                s.registered = false;
                s.locked = false;
                SharedPreferences.Editor e = prefs(c).edit();
                e.putBoolean(KEY_REGISTERED, false);
                e.putBoolean(KEY_SRV_LOCKED, false);   // forget the last "locked" so a 404 can't keep it locked
                e.putString(KEY_NEXT_LOCK, "");         // no schedule while unlinked
                e.putLong(KEY_LAST_SYNC, System.currentTimeMillis());
                e.apply();
            } else {
                s.ok = false;
            }
        } catch (Exception e) {
            s.ok = false; // network error
        } finally {
            if (conn != null) conn.disconnect();
        }
        return s;
    }

    /** True once the device has been linked to a customer in the panel. */
    public static boolean isRegistered(Context c) {
        return prefs(c).getBoolean(KEY_REGISTERED, false);
    }

    /** True once the device has been linked at least once (initial setup finished). */
    public static boolean everRegistered(Context c) {
        return prefs(c).getBoolean(KEY_EVER_REGISTERED, false);
    }

    /**
     * Setup is still pending: the app is protection-ready (device owner) but has NEVER been linked
     * to a customer yet. We keep the phone on the setup/lock screen until the dealer activates it,
     * so a freshly-provisioned phone can't be used until setup completes.
     */
    public static boolean setupPending(Context c) {
        return Locker.isDeviceOwner(c) && !everRegistered(c);
    }

    /**
     * The single source of truth for "should this phone be locked right now", given a fresh status.
     *  - ONLINE + linked (HTTP 200): trust the server's answer completely. A manual unlock, an
     *    auto-unlock (nothing overdue), or a confirmed payment all unlock immediately — the stored
     *    offline schedule never overrides a live server answer.
     *  - ONLINE + not linked (HTTP 404): the record is gone or never existed; only the setup gate
     *    can lock (so a freshly provisioned phone stays on the setup screen, but a de-linked phone
     *    does not stay bricked on stale data).
     *  - OFFLINE (network error): fall back to the setup gate + the last-known schedule, so turning
     *    off internet cannot dodge a real overdue lock.
     */
    public static boolean decideLock(Context c, Status s) {
        if (setupPending(c)) return true;                     // not activated yet -> stay locked
        int smsForce = prefs(c).getInt(KEY_SMS_FORCE, -1);
        if (smsForce == 1) return true;                       // SMS "LOCK" command (works offline)
        if (smsForce == 0) return false;                      // SMS "UNLOCK" command
        if (simViolation(c)) return true;                     // SIM pulled out or swapped (online + offline)
        if (s.ok && s.registered) return s.locked;            // online + linked: server answer wins
        if (s.ok && !s.registered) return false;              // 404: not linked (setup handled above)
        return shouldLockOffline(c);                          // offline: stored schedule
    }

    private static String todayStr() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /**
     * Offline-capable lock decision. Returns true if the device should be locked based on what we
     * last learned from the server, even if there is no internet right now:
     *  - the server last said locked, OR
     *  - the next due date has arrived and we haven't been told it's paid, OR
     *  - we haven't managed to sync for longer than the grace period.
     * Returns false until the device has synced at least once (not yet set up).
     */
    public static boolean shouldLockOffline(Context c) {
        SharedPreferences p = prefs(c);
        long lastSync = p.getLong(KEY_LAST_SYNC, 0);
        if (lastSync == 0) return false; // never synced yet
        // SIM-guard: SIM pulled out or swapped -> lock, even offline. Catches the common
        // "pull the SIM, then reset" attempt. (Covers both removal and a different SIM.)
        if (simViolation(c)) return true;
        if (p.getBoolean(KEY_SRV_LOCKED, false)) return true;
        int grace = p.getInt(KEY_GRACE, 2);
        long ageDays = (System.currentTimeMillis() - lastSync) / 86400000L;
        if (ageDays > grace) return true; // offline too long
        String next = p.getString(KEY_NEXT_LOCK, "");
        if (next != null && next.length() == 10 && todayStr().compareTo(next) >= 0) return true;
        return false;
    }

    private static String read(HttpURLConnection conn, boolean err) throws Exception {
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                err ? conn.getErrorStream() : conn.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
