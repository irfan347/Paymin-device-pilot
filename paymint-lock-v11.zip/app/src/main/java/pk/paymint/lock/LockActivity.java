package pk.paymint.lock;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;

/** Full-screen lock notice shown when an installment is overdue. Allows emergency calls. */
public class LockActivity extends Activity {

    private static WeakReference<LockActivity> INSTANCE;
    private TextView msgView;

    /** Called by the poller when the backend reports the device is no longer locked. */
    public static void dismiss() {
        if (INSTANCE != null) {
            LockActivity a = INSTANCE.get();
            if (a != null) a.runOnUiThread(a::unlockAndFinish);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        INSTANCE = new WeakReference<>(this);

        // Show over the keyguard and turn the screen on when the lock first appears.
        // We do NOT keep the screen on — it may sleep to save battery, and the lock
        // re-appears the moment the screen is woken (device stays on and locked).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }

        // If we're device owner, pin the screen and block the status bar / shortcuts.
        if (Locker.isDeviceOwner(this)) {
            try { startLockTask(); } catch (Exception ignored) {}
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                ComponentName admin = PaymintAdminReceiver.getComponent(this);
                dpm.setStatusBarDisabled(admin, true);
                // Keep emergency (keyguard) + system info, but NO global actions -> the long-press
                // power menu (Power off / Restart) is hidden while locked.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    dpm.setLockTaskFeatures(admin,
                            DevicePolicyManager.LOCK_TASK_FEATURE_KEYGUARD
                            | DevicePolicyManager.LOCK_TASK_FEATURE_SYSTEM_INFO);
                }
            } catch (Exception ignored) {}
        }

        setContentView(buildUi());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#0A2540"));
        int pad = dp(28);
        root.setPadding(pad, pad, pad, pad);

        TextView brand = new TextView(this);
        brand.setText("Paymint");
        brand.setTextColor(Color.parseColor("#12D6A0"));
        brand.setTextSize(28);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand);

        boolean setup = Api.setupPending(this);

        TextView lock = new TextView(this);
        lock.setText(setup ? "⚙️  Setup in progress" : "🔒  Device locked");
        lock.setTextColor(Color.WHITE);
        lock.setTextSize(22);
        lock.setGravity(Gravity.CENTER);
        lock.setPadding(0, dp(18), 0, dp(10));
        root.addView(lock);

        msgView = new TextView(this);
        if (setup) {
            msgView.setText("This phone is being set up on a Paymint installment plan. Give the device code below to your dealer to activate it. The phone unlocks once activation is complete.");
        } else {
            msgView.setText("An installment payment is overdue, so this device is locked — calls and apps are paused until payment. Emergency calls still work. Pay your due installment and the device unlocks automatically once your payment is confirmed.");
        }
        msgView.setTextColor(Color.parseColor("#C7D4E6"));
        msgView.setTextSize(16);
        msgView.setGravity(Gravity.CENTER);
        msgView.setPadding(0, 0, 0, dp(setup ? 14 : 28));
        root.addView(msgView);

        if (setup) {
            TextView codeLbl = new TextView(this);
            codeLbl.setText("Device code");
            codeLbl.setTextColor(Color.parseColor("#93A4BF"));
            codeLbl.setTextSize(13);
            codeLbl.setGravity(Gravity.CENTER);
            root.addView(codeLbl);
            TextView code = new TextView(this);
            code.setText(Api.deviceId(this));
            code.setTextColor(Color.parseColor("#12D6A0"));
            code.setTextSize(24);
            code.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            code.setGravity(Gravity.CENTER);
            code.setPadding(0, dp(2), 0, dp(24));
            root.addView(code);
        }

        if (!setup) {
            Button pay = mkBtn("💳  Pay now", R.drawable.btn_mint, "#04231B");
            pay.setOnClickListener(v -> showPayView());
            root.addView(pay, lp());
        }

        Button internet = mkBtn("📶  Internet / Wi-Fi", R.drawable.btn_soft, "#EAF1FB");
        internet.setOnClickListener(v -> openInternet());
        root.addView(internet, lp());

        Button refresh = mkBtn(setup ? "🔄  Check activation" : "✅  I've paid — check again", R.drawable.btn_soft, "#EAF1FB");
        refresh.setOnClickListener(v -> recheck());
        root.addView(refresh, lp());

        Button emergency = mkBtn("📞  Emergency call", R.drawable.btn_danger, "#FF8A95");
        emergency.setOnClickListener(v -> openEmergency());
        root.addView(emergency, lp());

        return root;
    }

    private boolean payOpen = false;
    private android.webkit.WebView payWeb;

    /** Opens the customer payment page (/me) inside the locked app, so they can pay and unlock. */
    private void showPayView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0B1220"));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#0A2540"));
        bar.setPadding(dp(10), dp(8), dp(10), dp(8));

        Button back = new Button(this);
        back.setText("← Back");
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.parseColor("#1E3350"));
        back.setOnClickListener(v -> showLockView());
        bar.addView(back);

        TextView t = new TextView(this);
        t.setText("  Pay your installment");
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        bar.addView(t);

        root.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        payWeb = new android.webkit.WebView(this);
        android.webkit.WebSettings s = payWeb.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        payWeb.setWebChromeClient(new android.webkit.WebChromeClient());
        payWeb.setWebViewClient(new android.webkit.WebViewClient());
        payWeb.loadUrl(Api.baseUrl(this) + "/me");
        root.addView(payWeb, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        payOpen = true;
        setContentView(root);
    }

    private void showLockView() {
        payOpen = false;
        if (payWeb != null) { try { payWeb.destroy(); } catch (Exception ignored) {} payWeb = null; }
        setContentView(buildUi());
    }

    /** Opens the connectivity panel so the customer can turn on Wi-Fi / mobile data to pay. */
    private void openInternet() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startActivity(new Intent(android.provider.Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            }
        } catch (Exception ignored) {}
        try { startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { Toast.makeText(this, "Open Settings to connect.", Toast.LENGTH_LONG).show(); }
    }

    /** Opens the dialer for emergency calls (dialer is allow-listed during kiosk). */
    private void openEmergency() {
        try {
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Toast.makeText(this, "Emergency: dial from the keyguard.", Toast.LENGTH_LONG).show();
        }
    }

    private void recheck() {
        Toast.makeText(this, "Checking…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            Api.Status s = Api.checkStatus(this);
            // Re-evaluate the full lock decision (online server answer wins; offline uses cache).
            boolean stillLocked = Api.decideLock(this, s);
            runOnUiThread(() -> {
                if (!stillLocked) unlockAndFinish();
                else if (Api.setupPending(this)) Toast.makeText(this, "Not activated yet. Ask your dealer to link this device code.", Toast.LENGTH_LONG).show();
                else if (s.ok) Toast.makeText(this, "Still unpaid. Please complete your payment.", Toast.LENGTH_LONG).show();
                else Toast.makeText(this, "No internet. Try again.", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private void unlockAndFinish() {
        if (Locker.isDeviceOwner(this)) {
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                dpm.setStatusBarDisabled(PaymintAdminReceiver.getComponent(this), false);
            } catch (Exception ignored) {}
            try { stopLockTask(); } catch (Exception ignored) {}
            try { Locker.setLockAsHome(this, false); } catch (Exception ignored) {}
        }
        finish();
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        // While the lock screen is showing, swallow the hardware keys so the customer can't fiddle:
        // volume up/down/mute, the power (menu) key, camera and recent-apps. They simply do nothing.
        int k = event.getKeyCode();
        if (k == android.view.KeyEvent.KEYCODE_VOLUME_UP
                || k == android.view.KeyEvent.KEYCODE_VOLUME_DOWN
                || k == android.view.KeyEvent.KEYCODE_VOLUME_MUTE
                || k == android.view.KeyEvent.KEYCODE_POWER
                || k == android.view.KeyEvent.KEYCODE_CAMERA
                || k == android.view.KeyEvent.KEYCODE_APP_SWITCH
                || k == android.view.KeyEvent.KEYCODE_MENU) {
            return true; // consumed -> button has no effect on the lock screen
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        // In the pay view, Back returns to the lock notice. On the lock notice, Back is blocked.
        if (payOpen) {
            if (payWeb != null && payWeb.canGoBack()) payWeb.goBack();
            else showLockView();
        }
        // else: stay locked until payment.
    }

    @Override
    protected void onDestroy() {
        if (INSTANCE != null && INSTANCE.get() == this) INSTANCE = null;
        super.onDestroy();
    }

    private Button mkBtn(String text, int bgRes, String textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15.5f);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.parseColor(textColor));
        try { b.setBackground(getResources().getDrawable(bgRes)); } catch (Exception ignored) {}
        b.setStateListAnimator(null);
        b.setElevation(0);
        int ph = dp(15);
        b.setPadding(0, ph, 0, ph);
        return b;
    }

    private LinearLayout.LayoutParams lp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                dp(300), LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(12);
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
