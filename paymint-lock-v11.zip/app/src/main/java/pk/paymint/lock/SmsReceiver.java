package pk.paymint.lock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

/**
 * SMS remote control. Lets the dealer lock/unlock a phone with a text message even when the phone
 * has NO internet (data off). Commands (case-insensitive), where <secret> is pushed by the server:
 *   PAYMINT LOCK <secret>     -> force lock now
 *   PAYMINT UNLOCK <secret>   -> release the lock
 * If no secret is configured on the server, the feature is disabled.
 */
public class SmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent == null || !"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
            String secret = Api.smsSecret(context);
            if (secret == null || secret.trim().isEmpty()) return; // feature off until server sets a secret

            StringBuilder body = new StringBuilder();
            Bundle b = intent.getExtras();
            if (b == null) return;
            Object[] pdus = (Object[]) b.get("pdus");
            if (pdus == null) return;
            String format = b.getString("format");
            for (Object pdu : pdus) {
                SmsMessage m = (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && format != null)
                        ? SmsMessage.createFromPdu((byte[]) pdu, format)
                        : SmsMessage.createFromPdu((byte[]) pdu);
                if (m != null && m.getMessageBody() != null) body.append(m.getMessageBody());
            }
            String msg = body.toString().trim();
            if (msg.isEmpty()) return;

            String lockCmd = ("PAYMINT LOCK " + secret).toLowerCase();
            String unlockCmd = ("PAYMINT UNLOCK " + secret).toLowerCase();
            String low = msg.toLowerCase();

            if (low.equals(lockCmd)) {
                Api.prefs(context).edit().putInt(Api.KEY_SMS_FORCE, 1).apply();
                Locker.apply(context, true);
            } else if (low.equals(unlockCmd)) {
                Api.prefs(context).edit().putInt(Api.KEY_SMS_FORCE, 0).apply();
                Locker.apply(context, false);
            }
        } catch (Throwable ignored) {}
    }
}
